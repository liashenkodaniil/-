# Стартова точка роботи програми
from Controller import Controller


def main():
    controller = Controller()
    controller.run()


if __name__ == "__main__":
    main()